package com.example.willowhealth

import android.content.Context
import java.util.Date

interface HealthReading {
    fun getSteps(context: Context,
                 endDate: Date,
                 callback: (HashMap<String, HashMap<String, HashMap<String, Int>>>) -> Unit)
}