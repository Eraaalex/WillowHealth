package com.example.willowhealth

enum class HealthMetrics {
    STEPS,
    CALORIES
}